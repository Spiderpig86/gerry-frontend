# How to Run this Project
* This project is created with TypeScript and React.
* All of the assets you need are located within this directory.

## Instructions
* Run an HTTP server to serve the project:, for example using Python:
    ```sh
    $ python3 -m http.server
    ```
* Then, load up `http://localhost:8000`.
* For more context on how to use, check out the screenshots and the gif.